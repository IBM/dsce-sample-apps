"build_image_insert.ipynb" notebook performs image insertion in Milvus.

Model is trained with the images available under "train" folder. 

When build_image_insert.ipynb is run, it takes Search image from the test folder and performs similarity search on images available in from frontend. 
