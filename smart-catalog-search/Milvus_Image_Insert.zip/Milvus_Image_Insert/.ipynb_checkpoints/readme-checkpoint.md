"build_image_search_engine.ipynb" notebook performs image similarity search on Milvus.

"Test" images are available under "test" folder.
Model is trained with the images available under "train" folder. 

When build_image_search_engine.ipynb is run, it takes Search image from the test folder and performs similarity search on images available in Milvus database. 
Search image can be modified in #cell9 of python notebook having header "Product search image path" 